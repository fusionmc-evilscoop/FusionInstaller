package net.minecraft.src;

import net.minecraft.src.*;
import net.minecraft.src.ic2.api.*;

public class CropChickenNest extends CropCard {

    public CropChickenNest() {
    }

    public String name() {
        return "H�hnernestpilz";
    }

    public String discoveredBy() {
        return "I Don't Now";
    }

    public int tier() {
        return 2;
    }

    public int stat(int n) {
        switch(n) {
        case 0:
            return 3;

        case 1:
            return 3;

        case 2:
            return 0;

        case 3:
            return 3;

        case 4:
            return 0;
            
        default:
        	return 0;
        }
    }

    public String[] attributes() {
        return (new String[] {
            "Ingredient", "Animal"
        });
    }

    public int getSpriteIndex(TECrop crop) {
    	return (int)crop.size + 38;
        }

    public boolean canGrow(TECrop crop) {
        return crop.size < 3;
    }

     public boolean canBeHarvested(TECrop crop) {
        return crop.size == 3;
    }

    public ItemStack getGain(TECrop crop) {
    	if(mod_IDNCrops.random.nextBoolean())
    		return new ItemStack(Item.feather , 1);
		return new ItemStack(Item.egg , 1);
    }

    public byte getSizeAfterHarvest(TECrop crop) {
        return 1;
    }

    public int growthDuration(TECrop crop) {
        return 400;
    }

    public String getTextureFile() {
        return "/idn_crops.png";
    }
}
