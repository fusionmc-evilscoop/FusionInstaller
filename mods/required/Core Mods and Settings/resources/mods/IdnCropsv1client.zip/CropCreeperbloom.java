package net.minecraft.src;

import net.minecraft.src.*;
import net.minecraft.src.ic2.api.*;

public class CropCreeperbloom extends CropCard {

    public CropCreeperbloom() {
    }

    public String name() {
        return "Kriecherbl�te";
    }

    public String discoveredBy() {
        return "I Don't Now";
    }

    public int tier() {
        return 6;
    }

    public int stat(int n) {
        switch(n) {
        case 0:
            return 3;

        case 1:
            return 0;

        case 2:
            return 0;

        case 3:
            return 3;

        case 4:
            return 0;
            
        default:
        	return 0;
        }
    }

    public String[] attributes() {
        return (new String[] {
            "Death", "Flower", "SSSSS"
        });
    }

    public int getSpriteIndex(TECrop crop) {
    	return (int)crop.size + 15;
        }

    public boolean canGrow(TECrop crop) {
        return crop.size < 4;
    }

     public boolean canBeHarvested(TECrop crop) {
        return crop.size == 4;
    }

    public ItemStack getGain(TECrop crop) {
        return new ItemStack(Item.gunpowder , mod_IDNCrops.random.nextInt(2) + 1);
    }

    public byte getSizeAfterHarvest(TECrop crop) {
        return 1;
    }

    public int growthDuration(TECrop crop) {
        return 1200;
    }

    public String getTextureFile() {
        return "/idn_crops.png";
    }
}
