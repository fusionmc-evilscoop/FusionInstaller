package net.minecraft.src;

import net.minecraft.src.*;
import net.minecraft.src.ic2.api.*;

public class CropEnderbloom extends CropCard {

    public CropEnderbloom() {
    }

    public String name() {
        return "Enderblume";
    }

    public String discoveredBy() {
        return "I Don't Now";
    }

    public int tier() {
        return 7;
    }

    public int stat(int n) {
        switch(n) {
        case 0:
            return 3;

        case 1:
            return 0;

        case 2:
            return 0;

        case 3:
            return 3;

        case 4:
            return 0;
            
        default:
        	return 0;
        }
    }

    public String[] attributes() {
        return (new String[] {
            "Death", "Flower", "End"
        });
    }

    public int getSpriteIndex(TECrop crop) {
    	return (int)crop.size + 19;
        }

    public boolean canGrow(TECrop crop) {
        return crop.size < 4;
    }

     public boolean canBeHarvested(TECrop crop) {
        return crop.size == 4;
    }

    public ItemStack getGain(TECrop crop) {
        return new ItemStack(Item.enderPearl , mod_IDNCrops.random.nextInt(2) + 1);
    }

    public byte getSizeAfterHarvest(TECrop crop) {
        return 1;
    }

    public int growthDuration(TECrop crop) {
        return 1400;
    }

    public String getTextureFile() {
        return "/idn_crops.png";
    }
}
