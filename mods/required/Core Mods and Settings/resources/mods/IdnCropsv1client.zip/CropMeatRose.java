package net.minecraft.src;

import net.minecraft.src.*;
import net.minecraft.src.ic2.api.*;

public class CropMeatRose extends CropCard {

    public CropMeatRose() {
    }

    public String name() {
        return "Fleischrose";
    }

    public String discoveredBy() {
        return "I Don't Now";
    }

    public int tier() {
        return 5;
    }

    public int stat(int n) {
        switch(n) {
        case 0:
            return 0;

        case 1:
            return 3;

        case 2:
            return 0;

        case 3:
            return 3;

        case 4:
            return 0;
            
        default:
        	return 0;
        }
    }

    public String[] attributes() {
        return (new String[] {
            "Food", "Animal",
        });
    }

    public int getSpriteIndex(TECrop crop) {
    	return (int)crop.size + 30;
        }

    public boolean canGrow(TECrop crop) {
        return crop.size < 4;
    }

     public boolean canBeHarvested(TECrop crop) {
        return crop.size == 4;
    }

    public ItemStack getGain(TECrop crop) {
    	switch(mod_IDNCrops.random.nextInt(4)) {
    	case 0: return new ItemStack(Item.chickenRaw , mod_IDNCrops.random.nextInt(2) + 1);
    	
    	case 1: return new ItemStack(Item.beefRaw , mod_IDNCrops.random.nextInt(2) + 1);
    	
    	case 2: return new ItemStack(Item.porkRaw , mod_IDNCrops.random.nextInt(2) + 1);
    	
    	default: return new ItemStack(Item.fishRaw , mod_IDNCrops.random.nextInt(2) + 1);
    	}
    }

    public byte getSizeAfterHarvest(TECrop crop) {
        return 1;
    }

    public int growthDuration(TECrop crop) {
        return 1000;
    }

    public String getTextureFile() {
        return "/idn_crops.png";
    }
}
