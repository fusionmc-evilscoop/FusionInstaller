package net.minecraft.src;

import net.minecraft.src.*;
import net.minecraft.src.ic2.api.*;

public class CropMilkwart extends CropCard {

    public CropMilkwart() {
    }

    public String name() {
        return "Milchwarze";
    }

    public String discoveredBy() {
        return "I Don't Now";
    }

    public int tier() {
        return 3;
    }

    public int stat(int n) {
        switch(n) {
        case 0:
            return 0;

        case 1:
            return 3;

        case 2:
            return 0;

        case 3:
            return 1;

        case 4:
            return 0;
            
        default:
        	return 0;
        }
    }

    public String[] attributes() {
        return (new String[] {
            "Animal", "Ingredient", "Liquid"
        });
    }

    public int getSpriteIndex(TECrop crop) {
    	return (int)crop.size + 27;
        }

    public boolean canGrow(TECrop crop) {
        return crop.size < 3;
    }

     public boolean canBeHarvested(TECrop crop) {
        return crop.size == 3;
    }

    public ItemStack getGain(TECrop crop) {
        return new ItemStack(Item.bucketMilk , 0);
    }

    public byte getSizeAfterHarvest(TECrop crop) {
        return 1;
    }

    public int growthDuration(TECrop crop) {
        return 600;
    }

    public String getTextureFile() {
        return "/idn_crops.png";
    }
    
    public float dropGainChance()
    {
    	return 0;
    }

    public boolean rightclick(TECrop crop, EntityPlayer player) {
    	
    	if(player.getCurrentEquippedItem() != null)
    	{
    		if(player.getCurrentEquippedItem().itemID == Item.bucketEmpty.shiftedIndex && crop.size == 3)
    		{
    			player.inventory.setInventorySlotContents(player.inventory.currentItem, new ItemStack(Item.bucketMilk, 1));
    			return crop.harvest(true);
    		}
    	}
    	
    	return false;
    }
}
