package net.minecraft.src;

import net.minecraft.src.*;
import net.minecraft.src.ic2.api.*;

public class CropSchleimig extends CropCard {

    public CropSchleimig() {
    }

    public String name() {
        return "Schleimig";
    }

    public String discoveredBy() {
        return "I Don't Now";
    }

    public int tier() {
        return 3;
    }

    public int stat(int n) {
        switch(n) {
        case 0:
            return 3;

        case 1:
            return 0;

        case 2:
            return 0;

        case 3:
            return 3;

        case 4:
            return 0;
            
        default:
        	return 0;
        }
    }

    public String[] attributes() {
        return (new String[] {
            "Death", "Slime"
        });
    }

    public int getSpriteIndex(TECrop crop) {
    	return (int)crop.size - 1;
        }

    public boolean canGrow(TECrop crop) {
        return crop.size < 4;
    }

     public boolean canBeHarvested(TECrop crop) {
        return crop.size == 4;
    }

    public ItemStack getGain(TECrop crop) {
        return new ItemStack(Item.slimeBall , mod_IDNCrops.random.nextInt(2) + 1);
    }

    public byte getSizeAfterHarvest(TECrop crop) {
        return 1;
    }

    public int growthDuration(TECrop crop) {
        return 600;
    }

    public String getTextureFile() {
        return "/idn_crops.png";
    }
}
