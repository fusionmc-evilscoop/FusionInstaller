package net.minecraft.src;

import java.util.Random;

import net.minecraft.src.ic2.api.*;
import net.minecraft.src.forge.*;
import net.minecraft.src.*;



public class mod_IDNCrops extends NetworkMod {
		public final static Random random = new Random( 1999 );

		public mod_IDNCrops() {
		}
		
		@Override
        public boolean clientSideRequired()
        {
                return true;
        }

        @Override
        public boolean serverSideRequired()
        {
                return false;
        }
        
		@Override	
		public String getVersion() {
			return "v0.1";
		}
	
		@Override
		public String getPriorities() {
			return "required-after:mod_IC2";
		}

		@Override
		public void load() {
			CropCard.registerCrop(new CropBlazeReed(), 130);
			CropCard.registerCrop(new CropChickenNest(), 131);
			CropCard.registerCrop(new CropCorium(), 132);
			CropCard.registerCrop(new CropCorpseplant(), 133);
			CropCard.registerCrop(new CropCreeperbloom(), 134);
			CropCard.registerCrop(new CropEnderbloom(), 135);
			CropCard.registerCrop(new CropMeatRose(), 136);
			CropCard.registerCrop(new CropMilkwart(), 137);
			CropCard.registerCrop(new CropSchleimig(), 138);
			CropCard.registerCrop(new CropSpidernip(), 139);
			CropCard.registerCrop(new CropTearStalks(), 140);
			
			CropCard.registerBaseSeed(new ItemStack(Item.blazeRod.shiftedIndex, 1, -1), 130, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.egg.shiftedIndex, 1, -1), 131, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.leather.shiftedIndex, 1, -1), 132, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.rottenFlesh.shiftedIndex, 1, -1), 133, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.gunpowder.shiftedIndex, 1, -1), 134, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.enderPearl.shiftedIndex, 1, -1), 135, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.chickenRaw.shiftedIndex, 1, -1), 136, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.beefRaw.shiftedIndex, 1, -1), 137, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.slimeBall.shiftedIndex, 1, -1), 138, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.spiderEye.shiftedIndex, 1, -1), 139, 1, 1, 1, 1);
			CropCard.registerBaseSeed(new ItemStack(Item.ghastTear.shiftedIndex, 1, -1), 140, 1, 1, 1, 1);

			MinecraftForgeClient.preloadTexture("/idn_crops.png");
		}
}